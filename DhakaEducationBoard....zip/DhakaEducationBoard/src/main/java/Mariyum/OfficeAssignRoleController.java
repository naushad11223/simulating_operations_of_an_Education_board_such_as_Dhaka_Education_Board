package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;
import java.util.List;

public class OfficeAssignRoleController {

    @FXML
    private Label feedbackLabel;

    @FXML
    private ChoiceBox<String> roleChoiceBox;

    @FXML
    private TableColumn<UserRole, String> roleCol;

    @FXML
    private TableColumn<UserRole, String> userNameCol;

    @FXML
    private TableColumn<UserRole, String> emailCol;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField emailField;

    @FXML
    private TableView<UserRole> userroletableview;

    private ObservableList<UserRole> userRoles = FXCollections.observableArrayList();
    private ObservableList<String> roles = FXCollections.observableArrayList("Admin", "User", "Manager", "Teacher", "Staff");

    // Action for assigning role to a user
    @FXML
    void assignRoleOnActionMouseclickButton(ActionEvent event) {
        String username = usernameField.getText();
        String role = roleChoiceBox.getValue();
        String email = emailField.getText();

        if (username != null && !username.isEmpty() && role != null && email != null && !email.isEmpty()) {
            UserRole userRole = new UserRole(username, role, email);
            userRoles.add(userRole);
            userroletableview.setItems(userRoles);
            feedbackLabel.setText("Role assigned successfully!");
            writeToFile(userRoles);
        } else {
            feedbackLabel.setText("Please enter a username, email, and select a role.");
        }
    }


    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {
        feedbackLabel.setText("Returning to home...");
    }


    public void writeToFile(ObservableList<UserRole> userRoles) {
        File file = new File("UserRolesData.bin");
        try (FileOutputStream fos = new FileOutputStream(file);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            for (UserRole userRole : userRoles) {
                oos.writeObject(userRole);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // Read user roles from the file
    public ObservableList<UserRole> readFromFile() {
        ObservableList<UserRole> userRolesList = FXCollections.observableArrayList();
        File file = new File("UserRolesData.bin");

        if (!file.exists()) return userRolesList;

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            while (true) {
                try {
                    UserRole userRole = (UserRole) ois.readObject();
                    userRolesList.add(userRole);
                } catch (EOFException e) {
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }

        return userRolesList;
    }


    @FXML
    public void initialize() {

        if (emailCol == null) {
            System.out.println("emailCol is null");
        } else {
            System.out.println("emailCol is properly initialized");
        }


        roleChoiceBox.setItems(roles);


        ObservableList<UserRole> storedUserRoles = readFromFile();
        userRoles.setAll(storedUserRoles);
        userroletableview.setItems(userRoles);


        if (userNameCol != null && roleCol != null && emailCol != null) {
            userNameCol.setCellValueFactory(new PropertyValueFactory<>("userName"));
            roleCol.setCellValueFactory(new PropertyValueFactory<>("role"));
            emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        } else {
            System.out.println("One or more table columns are null!");
        }
    }
}
