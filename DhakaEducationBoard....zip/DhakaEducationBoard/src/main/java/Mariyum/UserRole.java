package Mariyum;

import java.io.Serializable;

public class UserRole implements Serializable {
    private static final long serialVersionUID = 6497712666229238716L;

    private String userName;
    private String role;
    private String email;

    public UserRole(String userName, String role, String email) {
        this.userName = userName;
        this.role = role;
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
