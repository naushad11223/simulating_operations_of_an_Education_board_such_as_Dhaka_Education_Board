package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class OfficeGenerateReportController {

    @FXML
    private DatePicker datePicker;

    @FXML
    private TextArea reportDisplayTextArea;

    @FXML
    private ComboBox<String> reportTypeChoiceBox;

    private static final String FILE_NAME = "ReportData.bin";

    @FXML
    public void initialize() {
        // Populate the ComboBox with sample report types
        reportTypeChoiceBox.setItems(FXCollections.observableArrayList("Daily Report", "Weekly Report", "Monthly Report"));
    }

    @FXML
    void generateReportOnActionMouseclickButton(ActionEvent event) {
        String reportType = reportTypeChoiceBox.getValue();
        LocalDate date = datePicker.getValue();
        if (reportType == null || date == null) {
            reportDisplayTextArea.setText("Please select a report type and date.");
            return;
        }

        String formattedDate = date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String content = "This is a sample " + reportType + " generated on " + formattedDate + ".";

        Report report = new Report(reportType, formattedDate, content);


        writeReportToFile(report);


        reportDisplayTextArea.setText("Report Generated:\n" + report);
    }

    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {

    }

    public void writeReportToFile(Report report) {
        File file = new File(FILE_NAME);
        try (FileOutputStream fos = new FileOutputStream(file, true);
             ObjectOutputStream oos = file.exists() ? new AppendableObjectOutputStream(fos) : new ObjectOutputStream(fos)) {
            oos.writeObject(report);
        } catch (IOException ex) {
            System.out.println("Error writing to file: " + ex.getMessage());
        }
    }

    public ObservableList<Report> readReportsFromFile() {
        ObservableList<Report> reports = FXCollections.observableArrayList();
        File file = new File(FILE_NAME);

        if (!file.exists()) {
            return reports;
        }

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            while (true) {
                try {
                    Report report = (Report) ois.readObject();
                    reports.add(report);
                } catch (EOFException eof) {
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error reading from file: " + ex.getMessage());
        }

        return reports;
    }


    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {

        }
    }
}
