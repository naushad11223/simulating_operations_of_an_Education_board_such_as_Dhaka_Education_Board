package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

import java.io.*;
import java.util.List;

public class ExaminationnotifychairmanController {

    @FXML
    private TextArea messageInputTextArea;

    @FXML
    private Label statusLabel;

    private static final String FILE_NAME = "NotificationData.bin";

    @FXML
    void notifyChairmanOnActionMouseclickButton(ActionEvent event) {
        String message = messageInputTextArea.getText();

        if (message == null || message.trim().isEmpty()) {
            statusLabel.setText("Message cannot be empty!");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }


        int notificationId = generateNotificationId();
        String recipient = "Chairman";
        String status = "Pending";

        Notification notification = new Notification(notificationId, message, recipient, status);


        writeNotificationToFile(notification);

        statusLabel.setText("Notification sent successfully!");
        statusLabel.setStyle("-fx-text-fill: green;");
        messageInputTextArea.clear();
    }


    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {

        System.out.println("Return Home button clicked.");
    }

    public void writeNotificationToFile(Notification notification) {
        File f = new File(FILE_NAME);
        try (FileOutputStream fos = new FileOutputStream(f, true);
             ObjectOutputStream oos = f.exists() ? new AppendableObjectOutputStream(fos) : new ObjectOutputStream(fos)) {
            oos.writeObject(notification);
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }


    public ObservableList<Notification> readNotificationsFromFile() {
        ObservableList<Notification> notifications = FXCollections.observableArrayList();
        File f = new File(FILE_NAME);

        if (!f.exists()) {
            System.out.println("File not found: " + FILE_NAME);
            return notifications;
        }

        try (FileInputStream fis = new FileInputStream(f);
             ObjectInputStream ois = new ObjectInputStream(fis)) {

            while (true) {
                Notification notification = (Notification) ois.readObject();
                notifications.add(notification);
            }
        } catch (EOFException e) {

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }

        return notifications;
    }


    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {
            reset(); // Prevent overwriting the stream header
        }
    }


    private int generateNotificationId() {
        List<Notification> existingNotifications = readNotificationsFromFile();
        return existingNotifications.size() + 1;
    }
}
