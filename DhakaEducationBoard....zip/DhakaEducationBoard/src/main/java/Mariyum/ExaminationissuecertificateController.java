package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.*;

public class ExaminationissuecertificateController {

    @FXML
    private TableColumn<Certificate, String> certificatestatuscol;

    @FXML
    private TableColumn<Certificate, String> examidcol;

    @FXML
    private TableView<Certificate> issuedCertificatesTableView;

    @FXML
    private Label statusLabel;

    @FXML
    private TextField studentNameTextField1;

    @FXML
    private TableColumn<Certificate, String> studentidCol;

    @FXML
    private TextField studentidTextField;

    private ObservableList<Certificate> certificates = FXCollections.observableArrayList();

    private final String FILE_NAME = "CertificateData.bin";

    @FXML
    void initialize() {

        studentidCol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStudentId()));
        examidcol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getExamId()));
        certificatestatuscol.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));


        certificates = readCertificatesFromFile();
        issuedCertificatesTableView.setItems(certificates);
    }

    @FXML
    void issuecirtificateOnActionMouseclickButton(ActionEvent event) {
        String studentId = studentidTextField.getText();
        String examId = studentNameTextField1.getText();

        if (studentId.isEmpty() || examId.isEmpty()) {
            statusLabel.setText("Please fill all fields!");
            return;
        }


        Certificate newCertificate = new Certificate(studentId, examId, "Issued");
        certificates.add(newCertificate);


        writeCertificateToFile(newCertificate);


        statusLabel.setText("Certificate issued successfully!");


        studentidTextField.clear();
        studentNameTextField1.clear();
    }

    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {

        System.out.println("Return to Home button clicked.");
    }

    private void writeCertificateToFile(Certificate certificate) {
        try (FileOutputStream fos = new FileOutputStream(FILE_NAME, true);
             ObjectOutputStream oos = new AppendableObjectOutputStream(fos)) {

            oos.writeObject(certificate);

        } catch (IOException ex) {
            System.out.println("Error writing to file: " + ex.getMessage());
        }
    }

    private ObservableList<Certificate> readCertificatesFromFile() {
        ObservableList<Certificate> certificatesList = FXCollections.observableArrayList();

        try (FileInputStream fis = new FileInputStream(FILE_NAME);
             ObjectInputStream ois = new ObjectInputStream(fis)) {

            while (true) {
                Certificate certificate = (Certificate) ois.readObject();
                certificatesList.add(certificate);
            }

        } catch (EOFException ex) {

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error reading from file: " + ex.getMessage());
        }

        return certificatesList;
    }

    /**
     * Custom ObjectOutputStream to prevent overwriting the header for appending objects to the file.
     */
    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {

            reset();
        }
    }
}
