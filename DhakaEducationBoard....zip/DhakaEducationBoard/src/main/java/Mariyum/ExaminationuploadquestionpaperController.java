package Mariyum;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.*;
import java.util.List;

public class ExaminationuploadquestionpaperController {

    @FXML
    private TableColumn<Examination, String> examNameCol;

    @FXML
    private ComboBox<String> examNameComboBox1;

    @FXML
    private Label examnamelabel;

    @FXML
    private TableView<Examination> examsheduletableview;

    @FXML
    private Label feedbackLabel;

    @FXML
    private Label previousqustionpaperLabel;

    @FXML
    private TableColumn<Examination, String> statusCol;

    @FXML
    private TableColumn<Examination, String> subjectCol;

    @FXML
    private ComboBox<String> subjectComboBox;

    @FXML
    private Label subjectLabel;

    @FXML
    private TextField uploadeSuccessfultextfield;

    @FXML
    private TableColumn<Examination, String> venueCol;


    @FXML
    void fileselectOnActionMouseclickButton(ActionEvent event) {

    }

    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {

    }

    @FXML
    void uploadfilesOnActionMouseclickButton(ActionEvent event) {
        String examName = examNameComboBox1.getValue();
        String subject = subjectComboBox.getValue();
        String fileName = "examfile.pdf";
        String year = "2024";

        Examination examination = new Examination(examName, subject, fileName, year);

        writeExaminationToFile(examination);

        examsheduletableview.getItems().add(examination);
        feedbackLabel.setText("Examination data uploaded successfully!");
    }

    public void writeExaminationToFile(Examination examination) {
        File file = new File("ExaminationData.bin");
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;

        try {
            if (file.exists()) {
                fos = new FileOutputStream(file, true); // Append mode
                oos = new AppendableObjectOutputStream(fos);
            } else {
                fos = new FileOutputStream(file);
                oos = new ObjectOutputStream(fos);
            }
            oos.writeObject(examination);

        } catch (IOException ex) {
            System.out.println(ex);
        } finally {
            try {
                if (oos != null) oos.close();
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }
    }


    public ObservableList<Examination> readExaminationFromFile() {
        ObservableList<Examination> examinationList = FXCollections.observableArrayList();

        File file = new File("ExaminationData.bin");
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        try {
            fis = new FileInputStream(file);
            ois = new ObjectInputStream(fis);

            Examination examination;
            while (true) {
                try {
                    examination = (Examination) ois.readObject();
                    examinationList.add(examination);
                } catch (EOFException e) {
                    break;
                }
            }

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex);
        } finally {
            try {
                if (ois != null) ois.close();
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }

        return examinationList;
    }

    public void initialize() {
        ObservableList<String> examNames = FXCollections.observableArrayList("Exam 1", "Exam 2", "Exam 3");
        examNameComboBox1.setItems(examNames);

        ObservableList<String> subjects = FXCollections.observableArrayList("Math", "Physics", "Chemistry");
        subjectComboBox.setItems(subjects);

        ObservableList<Examination> examinationList = readExaminationFromFile();
        examsheduletableview.setItems(examinationList);

        examNameCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getExamName()));
        subjectCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getSubject()));
        venueCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getYear()));
        statusCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getFileName()));
    }

    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {

        }
    }
}
