package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.*;
import java.util.List;

public class OfficetrackfeepaymentController {

    @FXML
    private TableView<FeePayment> paymentRecordsTableView;

    @FXML
    private TableColumn<FeePayment, String> studentNameCol;

    @FXML
    private TableColumn<FeePayment, String> paymentStatusCol;

    @FXML
    private ChoiceBox<String> paymentStatusComboBox;

    @FXML
    private TextField studentIdField;

    // Method to write FeePayment object to a file
    public void feePaymentFileWrite(FeePayment feePayment) {
        File file = new File("FeePaymentData.bin");
        try (FileOutputStream fos = new FileOutputStream(file, true);
             ObjectOutputStream oos = file.exists() ? new AppendableObjectOutputStream(fos) : new ObjectOutputStream(fos)) {
            oos.writeObject(feePayment);
        } catch (IOException ex) {
            System.out.println("Error writing to file: " + ex.getMessage());
        }
    }

    // Method to read FeePayment objects from a file
    public ObservableList<FeePayment> feePaymentFileRead() {
        ObservableList<FeePayment> feePayments = FXCollections.observableArrayList();
        File file = new File("FeePaymentData.bin");

        if (!file.exists()) {
            return feePayments;
        }

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            while (true) {
                FeePayment feePayment = (FeePayment) ois.readObject();
                feePayments.add(feePayment);
            }
        } catch (EOFException e) {
            // End of file reached, no more data
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error reading from file: " + ex.getMessage());
        }

        return feePayments;
    }

    // Method to populate the ChoiceBox with payment statuses
    private void populatePaymentStatusComboBox() {
        ObservableList<String> paymentStatuses = FXCollections.observableArrayList("Paid", "Pending", "Overdue");
        paymentStatusComboBox.setItems(paymentStatuses);
    }

    // Action handler for the "Search" button
    @FXML
    void searchOnActionMouseclickButton(ActionEvent event) {
        String studentId = studentIdField.getText();
        String paymentStatus = paymentStatusComboBox.getValue();

        // Filter the fee payments based on student ID and payment status
        ObservableList<FeePayment> feePayments = feePaymentFileRead();
        ObservableList<FeePayment> filteredFeePayments = FXCollections.observableArrayList();

        for (FeePayment feePayment : feePayments) {
            boolean matchesStudentId = studentId.isEmpty() || feePayment.getStudentId().equals(studentId);
            boolean matchesPaymentStatus = paymentStatus == null || feePayment.getPaymentStatus().equals(paymentStatus);

            if (matchesStudentId && matchesPaymentStatus) {
                filteredFeePayments.add(feePayment);
            }
        }

        // Update the TableView with filtered records
        paymentRecordsTableView.setItems(filteredFeePayments);
    }

    // Action handler for the "Return Home" button
    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {
        // Implement the logic to navigate back to the home screen
    }

    // Custom ObjectOutputStream to handle appending objects
    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {
            reset(); // Prevent overwriting the file
        }
    }

    // You can also use this method to add a sample FeePayment for testing
    public void addSampleFeePayment() {
        FeePayment samplePayment = new FeePayment("S123", "John Doe", "Paid");
        feePaymentFileWrite(samplePayment);
    }

    // Initialize method to set up the ChoiceBox and other UI components
    @FXML
    public void initialize() {
        // Populate the ChoiceBox with payment status options
        populatePaymentStatusComboBox();

        // Optionally, you can call the method to add sample fee payments for testing
        // addSampleFeePayment();
    }
}
