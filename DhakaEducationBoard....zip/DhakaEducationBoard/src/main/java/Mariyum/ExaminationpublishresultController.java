package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.io.*;

public class ExaminationpublishresultController {

    @FXML
    private TableView<Result> resultTable;

    @FXML
    private TableColumn<Result, String> studentNameCol;
    @FXML
    private TableColumn<Result, String> rollNumberCol;
    @FXML
    private TableColumn<Result, Double> marksCol;
    @FXML
    private TableColumn<Result, String> gradeCol;
    @FXML
    private TableColumn<Result, String> statusCol;


    @FXML
    public void initialize() {
        studentNameCol.setCellValueFactory(cellData -> cellData.getValue().studentNameProperty());
        rollNumberCol.setCellValueFactory(cellData -> cellData.getValue().rollNumberProperty());
        marksCol.setCellValueFactory(cellData -> cellData.getValue().marksProperty().asObject());
        gradeCol.setCellValueFactory(cellData -> cellData.getValue().gradeProperty());
        statusCol.setCellValueFactory(cellData -> cellData.getValue().statusProperty());
    }

    public void resultFileWrite(Result result) {
        File file = new File("ResultsData.bin");
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;

        try {
            if (file.exists()) {
                fos = new FileOutputStream(file, true); // Append mode
                oos = new AppendableObjectOutputStream(fos);
            } else {
                fos = new FileOutputStream(file);
                oos = new ObjectOutputStream(fos);
            }
            oos.writeObject(result);
        } catch (IOException ex) {
            System.out.println("Error writing result: " + ex.getMessage());
        } finally {
            try {
                if (oos != null) oos.close();
            } catch (IOException ex) {
                System.out.println("Error closing ObjectOutputStream: " + ex.getMessage());
            }
        }
    }


    public ObservableList<Result> resultFileRead() {
        ObservableList<Result> results = FXCollections.observableArrayList();

        File file = new File("ResultsData.bin");
        if (!file.exists()) {
            return results; // If file doesn't exist, return empty list
        }

        FileInputStream fis = null;
        ObjectInputStream ois = null;

        try {
            fis = new FileInputStream(file);
            ois = new ObjectInputStream(fis);

            Result result;
            try {
                while (true) {
                    result = (Result) ois.readObject();
                    results.add(result);
                }
            } catch (EOFException e) {

            }
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error reading results: " + ex.getMessage());
        } finally {
            try {
                if (ois != null) ois.close();
            } catch (IOException ex) {
                System.out.println("Error closing ObjectInputStream: " + ex.getMessage());
            }
        }

        return results;
    }

    public void loadResultsToTable() {
        ObservableList<Result> results = resultFileRead();
        resultTable.setItems(results);
    }


    @FXML
    public void publishAllResultsOnActionMouseclickButton() {

        System.out.println("Publishing all results...");
    }

    @FXML
    public void publishSelectedOnActionMouseclickButton() {

        Result selectedResult = resultTable.getSelectionModel().getSelectedItem();
        if (selectedResult != null) {
            System.out.println("Publishing selected result for: " + selectedResult.getStudentName());
        } else {
            System.out.println("No result selected to publish.");
        }
    }


    @FXML
    public void uploadResultsFileOnActionMouseclickButton() {
        // Add logic for file upload here
        System.out.println("Uploading results file...");
    }


    @FXML
    public void viewPublishedResultsOnActionMouseclickButton() {
        loadResultsToTable();
        System.out.println("Viewing published results...");
    }
}
