module com.example.dhakaeducationboard {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.dhakaeducationboard to javafx.fxml;
    opens Mariyum to javafx.fxml;

    exports com.example.dhakaeducationboard;

   // exports Mariyum;
}