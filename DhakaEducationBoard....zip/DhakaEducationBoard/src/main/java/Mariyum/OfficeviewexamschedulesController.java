package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.*;

public class OfficeviewexamschedulesController {

    @FXML
    private TableColumn<ExamSchedule, String> dateCol;

    @FXML
    private TableColumn<ExamSchedule, String> examNameCol;

    @FXML
    private TableView<ExamSchedule> examsheduletableview;

    @FXML
    private TextField filteringexamschedulestextfield;

    @FXML
    private Label instructionsLabel;

    @FXML
    private TableColumn<ExamSchedule, String> statusCol;

    @FXML
    private TableColumn<ExamSchedule, String> subjectCol;

    @FXML
    private TableColumn<ExamSchedule, String> timeCol;

    @FXML
    private TableColumn<ExamSchedule, String> venueCol;

    // Method to write ExamSchedule object to a file
    public void examScheduleFileWrite(ExamSchedule examSchedule) {
        File file = new File("ExamScheduleData.bin");
        try (FileOutputStream fos = new FileOutputStream(file, true);
             ObjectOutputStream oos = file.exists() ? new AppendableObjectOutputStream(fos) : new ObjectOutputStream(fos)) {
            oos.writeObject(examSchedule);
        } catch (IOException ex) {
            System.out.println("Error writing to file: " + ex.getMessage());
        }
    }

    // Method to read ExamSchedule objects from a file
    public ObservableList<ExamSchedule> examScheduleFileRead() {
        ObservableList<ExamSchedule> examSchedules = FXCollections.observableArrayList();
        File file = new File("ExamScheduleData.bin");

        if (!file.exists()) {
            return examSchedules;
        }

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            while (true) {
                ExamSchedule examSchedule = (ExamSchedule) ois.readObject();
                examSchedules.add(examSchedule);
            }
        } catch (EOFException e) {
            // End of file reached, no more data
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error reading from file: " + ex.getMessage());
        }

        return examSchedules;
    }

    // Method to filter exam schedules based on search criteria
    @FXML
    void searchOnActionMouseclickButton(ActionEvent event) {
        String searchTerm = filteringexamschedulestextfield.getText().toLowerCase();
        ObservableList<ExamSchedule> examSchedules = examScheduleFileRead();
        ObservableList<ExamSchedule> filteredSchedules = FXCollections.observableArrayList();

        for (ExamSchedule examSchedule : examSchedules) {
            if (examSchedule.getExamName().toLowerCase().contains(searchTerm) ||
                    examSchedule.getSubject().toLowerCase().contains(searchTerm)) {
                filteredSchedules.add(examSchedule);
            }
        }

        // Update the TableView with filtered schedules
        examsheduletableview.setItems(filteredSchedules);
    }

    // Action handler for the "Refresh" button
    @FXML
    void refreshOnActionMouseclickButton(ActionEvent event) {
        // Optionally, refresh the table with all exam schedules
        examsheduletableview.setItems(examScheduleFileRead());
    }

    // Action handler for the "Return Home" button
    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {
        // Implement the logic to navigate back to the home screen
    }

    // Custom ObjectOutputStream to handle appending objects
    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {
            reset(); // Prevent overwriting the file
        }
    }

    // Initialize method to set up the TableView and other UI components
    @FXML
    public void initialize() {
        // Set up the columns in the TableView
        examNameCol.setCellValueFactory(cellData -> cellData.getValue().examNameProperty());
        dateCol.setCellValueFactory(cellData -> cellData.getValue().dateProperty());
        timeCol.setCellValueFactory(cellData -> cellData.getValue().timeProperty());
        subjectCol.setCellValueFactory(cellData -> cellData.getValue().subjectProperty());
        venueCol.setCellValueFactory(cellData -> cellData.getValue().venueProperty());
        statusCol.setCellValueFactory(cellData -> cellData.getValue().statusProperty());

        // Load all exam schedules when the controller is initialized
        examsheduletableview.setItems(examScheduleFileRead());
    }
}
