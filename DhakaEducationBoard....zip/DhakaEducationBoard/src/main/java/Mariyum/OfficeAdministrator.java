package Mariyum;

import java.io.Serializable;

public class OfficeAdministrator implements Serializable {
    private String role;
    private String userName;
    private String status;

    public OfficeAdministrator(String role, String userName, String status) {
        this.role = role;
        this.userName = userName;
        this.status = status;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "OfficeAdministrator{" +
                "role='" + role + '\'' +
                ", userName='" + userName + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
