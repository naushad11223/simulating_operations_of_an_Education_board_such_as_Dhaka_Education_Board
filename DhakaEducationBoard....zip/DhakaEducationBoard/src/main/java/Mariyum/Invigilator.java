package Mariyum;

import java.io.Serializable;

public class Invigilator implements Serializable {
    private static final long serialVersionUID = 1L; // Added serialVersionUID for proper serialization

    private String name;
    private String responsibilities;


    public Invigilator(String name, String responsibilities) {
        this.name = name;
        this.responsibilities = responsibilities;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getResponsibilities() {
        return responsibilities;
    }

    public void setResponsibilities(String responsibilities) {
        this.responsibilities = responsibilities;
    }


    @Override
    public String toString() {
        return "Invigilator{" +
                "name='" + name + '\'' +
                ", responsibilities='" + responsibilities + '\'' +
                '}';
    }
}
