package Mariyum;

import java.io.Serializable;

public class RegisteredStudent implements Serializable {

    private String studentName;
    private String rollNumber;
    private String studentClass;
    private String exam;
    private String subject;

    // Constructor
    public RegisteredStudent(String studentName, String rollNumber, String studentClass, String exam, String subject) {
        this.studentName = studentName;
        this.rollNumber = rollNumber;
        this.studentClass = studentClass;
        this.exam = exam;
        this.subject = subject;
    }

    // Getters and Setters
    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getStudentClass() {
        return studentClass;
    }

    public void setStudentClass(String studentClass) {
        this.studentClass = studentClass;
    }

    public String getExam() {
        return exam;
    }

    public void setExam(String exam) {
        this.exam = exam;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return "RegisteredStudent{" +
                "studentName='" + studentName + '\'' +
                ", rollNumber='" + rollNumber + '\'' +
                ", studentClass='" + studentClass + '\'' +
                ", exam='" + exam + '\'' +
                ", subject='" + subject + '\'' +
                '}';
    }
}
