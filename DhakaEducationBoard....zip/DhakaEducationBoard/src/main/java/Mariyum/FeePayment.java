package Mariyum;

import java.io.Serializable;

public class FeePayment implements Serializable {
    private String studentId;
    private String studentName;
    private String paymentStatus;


    public FeePayment(String studentId, String studentName, String paymentStatus) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.paymentStatus = paymentStatus;
    }


    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    @Override
    public String toString() {
        return "FeePayment{" +
                "studentId='" + studentId + '\'' +
                ", studentName='" + studentName + '\'' +
                ", paymentStatus='" + paymentStatus + '\'' +
                '}';
    }
}
