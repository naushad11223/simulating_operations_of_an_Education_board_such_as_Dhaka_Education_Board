package Mariyum;

import java.io.Serializable;

public class Report implements Serializable {
    private String reportType;
    private String date;
    private String content;

    // Constructor
    public Report(String reportType, String date, String content) {
        this.reportType = reportType;
        this.date = date;
        this.content = content;
    }

    // Getters and Setters
    public String getReportType() {
        return reportType;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "Report{" +
                "reportType='" + reportType + '\'' +
                ", date='" + date + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
