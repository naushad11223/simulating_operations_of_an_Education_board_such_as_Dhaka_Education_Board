package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;

public class OfficeManageUserAccountController {

    @FXML
    private TableColumn<UserAccount, String> emailCol;

    @FXML
    private TextField emailField;

    @FXML
    private Label feedbackLabel;

    @FXML
    private TextField passwordtextField;

    @FXML
    private ChoiceBox<String> roleChoiceBox;

    @FXML
    private TableColumn<UserAccount, String> roleCol;

    @FXML
    private TableColumn<UserAccount, String> userNameCol;

    @FXML
    private TableView<UserAccount> usertableview;

    @FXML
    private TextField usernameField; // Declare usernameField here

    private static final String FILE_NAME = "UserAccountsData.bin";

    // Method to write a user account to the file
    public void userFileWrite(UserAccount user) {
        File file = new File(FILE_NAME);
        try (FileOutputStream fos = new FileOutputStream(file, true);
             ObjectOutputStream oos = file.exists() ? new AppendableObjectOutputStream(fos) : new ObjectOutputStream(fos)) {
            oos.writeObject(user);
            feedbackLabel.setText("User saved successfully!");
        } catch (IOException ex) {
            feedbackLabel.setText("Error saving user: " + ex.getMessage());
        }
    }

    // Method to read all user accounts from the file
    public ObservableList<UserAccount> userFileRead() {
        ObservableList<UserAccount> users = FXCollections.observableArrayList();
        File file = new File(FILE_NAME);

        if (!file.exists()) return users;

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            while (true) {
                UserAccount user = (UserAccount) ois.readObject();
                users.add(user);
            }
        } catch (EOFException eof) {
            // End of file reached, normal termination
        } catch (IOException | ClassNotFoundException ex) {
            feedbackLabel.setText("Error reading user data: " + ex.getMessage());
        }

        return users;
    }

    // Action handler for the "Create User" button
    @FXML
    void createuserOnActionMouseclickButton(ActionEvent event) {
        String username = usernameField.getText();
        String email = emailField.getText();
        String password = passwordtextField.getText();
        String role = roleChoiceBox.getValue();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || role == null) {
            feedbackLabel.setText("All fields must be filled!");
            return;
        }

        UserAccount newUser = new UserAccount(username, email, password, role);
        userFileWrite(newUser);
        usertableview.getItems().add(newUser);

        feedbackLabel.setText("User created successfully!");
        clearFields();
    }

    // Action handler for the "Delete User" button
    @FXML
    public void deleteuserOnActionMouseclickButton(ActionEvent event) {
        UserAccount selectedUser = usertableview.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            feedbackLabel.setText("Please select a user to delete!");
            return;
        }

        // Remove from table
        usertableview.getItems().remove(selectedUser);

        // Rewrite file without the deleted user
        ObservableList<UserAccount> remainingUsers = usertableview.getItems();
        try (FileOutputStream fos = new FileOutputStream(FILE_NAME);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            for (UserAccount user : remainingUsers) {
                oos.writeObject(user);
            }
            feedbackLabel.setText("User deleted successfully!");
        } catch (IOException ex) {
            feedbackLabel.setText("Error deleting user: " + ex.getMessage());
        }
    }

    // Action handler for "Activate/Deactivate" button
    @FXML
    public void activateDeactivateOnActionMouseclickButton(ActionEvent event) {
        UserAccount selectedUser = usertableview.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            feedbackLabel.setText("Please select a user to activate/deactivate!");
            return;
        }

        // Toggle activation status
        selectedUser.setActive(!selectedUser.isActive());
        usertableview.refresh();

        feedbackLabel.setText(selectedUser.isActive() ? "User activated!" : "User deactivated!");

        // Rewrite file to persist changes
        ObservableList<UserAccount> updatedUsers = usertableview.getItems();
        try (FileOutputStream fos = new FileOutputStream(FILE_NAME);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            for (UserAccount user : updatedUsers) {
                oos.writeObject(user);
            }
        } catch (IOException ex) {
            feedbackLabel.setText("Error updating user activation status: " + ex.getMessage());
        }
    }

    // Action handler for the "Return Home" button
    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {
        feedbackLabel.setText("Returning to home...");
        // Implement navigation logic if needed
    }

    // Clear all input fields
    private void clearFields() {
        usernameField.clear();
        emailField.clear();
        passwordtextField.clear();
        roleChoiceBox.setValue(null);
    }

    // Initialize method to set up ChoiceBox and TableView
    @FXML
    public void initialize() {
        roleChoiceBox.setItems(FXCollections.observableArrayList("Admin", "Editor", "Viewer"));

        userNameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        roleCol.setCellValueFactory(new PropertyValueFactory<>("role"));

        usertableview.setItems(userFileRead());
    }

    // Action handler for "Edit User" button
    @FXML
    public void edituserOnActionMouseclickButton(ActionEvent event) {
        UserAccount selectedUser = usertableview.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            feedbackLabel.setText("Please select a user to edit!");
            return;
        }


        feedbackLabel.setText("Editing user: " + selectedUser.getUsername());
    }

    public void activateDeactivatactivateDeactivateOnActionMouseclickButtone(ActionEvent actionEvent) {

    }

    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {
            reset();
        }
    }
}
