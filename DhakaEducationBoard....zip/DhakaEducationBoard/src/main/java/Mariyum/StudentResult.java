package Mariyum;

import java.io.Serializable;

public class StudentResult implements Serializable {
    private String studentName;
    private String rollNumber;
    private int marks;
    private String grade;
    private String status;

    // Constructor
    public StudentResult(String studentName, String rollNumber, int marks, String grade, String status) {
        this.studentName = studentName;
        this.rollNumber = rollNumber;
        this.marks = marks;
        this.grade = grade;
        this.status = status;
    }

    // Getters and Setters
    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "StudentResult{" +
                "studentName='" + studentName + '\'' +
                ", rollNumber='" + rollNumber + '\'' +
                ", marks=" + marks +
                ", grade='" + grade + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
