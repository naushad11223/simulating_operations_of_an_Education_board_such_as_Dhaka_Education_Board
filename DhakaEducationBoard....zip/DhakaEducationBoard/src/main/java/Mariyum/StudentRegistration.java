package Mariyum;

import javafx.beans.property.*;
import java.io.Serializable;

public class StudentRegistration implements Serializable {
    private StringProperty studentName;
    private StringProperty rollNumber;
    private StringProperty studentClass;
    private StringProperty exam;
    private StringProperty subject;

    // Constructor
    public StudentRegistration(String studentName, String rollNumber, String studentClass, String exam, String subject) {
        this.studentName = new SimpleStringProperty(studentName);
        this.rollNumber = new SimpleStringProperty(rollNumber);
        this.studentClass = new SimpleStringProperty(studentClass);
        this.exam = new SimpleStringProperty(exam);
        this.subject = new SimpleStringProperty(subject);
    }

    // Getters and Setters
    public StringProperty studentNameProperty() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName.set(studentName);
    }

    public String getStudentName() {
        return studentName.get();
    }

    public StringProperty rollNumberProperty() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber.set(rollNumber);
    }

    public String getRollNumber() {
        return rollNumber.get();
    }

    public StringProperty studentClassProperty() {
        return studentClass;
    }

    public void setStudentClass(String studentClass) {
        this.studentClass.set(studentClass);
    }

    public String getStudentClass() {
        return studentClass.get();
    }

    public StringProperty examProperty() {
        return exam;
    }

    public void setExam(String exam) {
        this.exam.set(exam);
    }

    public String getExam() {
        return exam.get();
    }

    public StringProperty subjectProperty() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject.set(subject);
    }

    public String getSubject() {
        return subject.get();
    }

    @Override
    public String toString() {
        return "StudentRegistration{" +
                "studentName='" + studentName.get() + '\'' +
                ", rollNumber='" + rollNumber.get() + '\'' +
                ", studentClass='" + studentClass.get() + '\'' +
                ", exam='" + exam.get() + '\'' +
                ", subject='" + subject.get() + '\'' +
                '}';
    }
}
