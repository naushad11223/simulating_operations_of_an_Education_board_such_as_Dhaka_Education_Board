package Mariyum;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.io.Serializable;

public class ExamSchedule implements Serializable {
    private static final long serialVersionUID = 1L; // Added serialVersionUID for proper serialization

    private StringProperty examName;
    private StringProperty date;
    private StringProperty time;
    private StringProperty subject;
    private StringProperty venue;
    private StringProperty status;

    // Constructor
    public ExamSchedule(String examName, String date, String time, String subject, String venue, String status) {
        this.examName = new SimpleStringProperty(examName);
        this.date = new SimpleStringProperty(date);
        this.time = new SimpleStringProperty(time);
        this.subject = new SimpleStringProperty(subject);
        this.venue = new SimpleStringProperty(venue);
        this.status = new SimpleStringProperty(status);
    }


    public StringProperty examNameProperty() {
        return examName;
    }

    public String getExamName() {
        return examName.get();
    }

    public void setExamName(String examName) {
        this.examName.set(examName);
    }

    public StringProperty dateProperty() {
        return date;
    }

    public String getDate() {
        return date.get();
    }

    public void setDate(String date) {
        this.date.set(date);
    }

    public StringProperty timeProperty() {
        return time;
    }

    public String getTime() {
        return time.get();
    }

    public void setTime(String time) {
        this.time.set(time);
    }

    public StringProperty subjectProperty() {
        return subject;
    }

    public String getSubject() {
        return subject.get();
    }

    public void setSubject(String subject) {
        this.subject.set(subject);
    }

    public StringProperty venueProperty() {
        return venue;
    }

    public String getVenue() {
        return venue.get();
    }

    public void setVenue(String venue) {
        this.venue.set(venue);
    }

    public StringProperty statusProperty() {
        return status;
    }

    public String getStatus() {
        return status.get();
    }

    public void setStatus(String status) {
        this.status.set(status);
    }


    @Override
    public String toString() {
        return "ExamSchedule{" +
                "examName='" + examName.get() + '\'' +
                ", date='" + date.get() + '\'' +
                ", time='" + time.get() + '\'' +
                ", subject='" + subject.get() + '\'' +
                ", venue='" + venue.get() + '\'' +
                ", status='" + status.get() + '\'' +
                '}';
    }
}
