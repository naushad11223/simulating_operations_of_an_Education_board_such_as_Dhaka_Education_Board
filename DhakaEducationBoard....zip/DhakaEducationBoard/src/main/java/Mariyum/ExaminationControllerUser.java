package Mariyum;

import java.io.Serializable;
import java.util.List;

public class ExaminationControllerUser implements Serializable {

    private String controllerId;
    private String name;
    private String email;
    private String phoneNumber;
    private String department;
    private List<String> assignedExams;
    private List<String> notifications;

    public ExaminationControllerUser(String controllerId, String name, String email, String phoneNumber,
                                 String department, List<String> assignedExams, List<String> notifications) {
        this.controllerId = controllerId;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.department = department;
        this.assignedExams = assignedExams;
        this.notifications = notifications;
    }

    // Getters and Setters
    public String getControllerId() {
        return controllerId;
    }

    public void setControllerId(String controllerId) {
        this.controllerId = controllerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public List<String> getAssignedExams() {
        return assignedExams;
    }

    public void setAssignedExams(List<String> assignedExams) {
        this.assignedExams = assignedExams;
    }

    public List<String> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<String> notifications) {
        this.notifications = notifications;
    }

    // toString method
    @Override
    public String toString() {
        return "ExaminationController [controllerId=" + controllerId + ", name=" + name + ", email=" + email
                + ", phoneNumber=" + phoneNumber + ", department=" + department + ", assignedExams=" + assignedExams
                + ", notifications=" + notifications + "]";
    }
}
