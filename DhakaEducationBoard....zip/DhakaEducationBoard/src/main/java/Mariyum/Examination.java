package Mariyum;

import java.io.Serializable;

public class Examination implements Serializable {

    private String examName;
    private String subject;
    private String fileName;
    private String year;

    public Examination(String examName, String subject, String fileName, String year) {
        this.examName = examName;
        this.subject = subject;
        this.fileName = fileName;
        this.year = year;
    }

    // Getters and Setters
    public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        this.examName = examName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "Examination{" +
                "examName='" + examName + '\'' +
                ", subject='" + subject + '\'' +
                ", fileName='" + fileName + '\'' +
                ", year='" + year + '\'' +
                '}';
    }
}
