package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.io.*;

public class ExaminationCompilesandpublishesresultsController {

    @FXML
    private TableColumn<Result, String> gradecol;

    @FXML
    private TableColumn<Result, Double> markscol;

    @FXML
    private TableView<Result> resultsTableView;

    @FXML
    private Label statusLabel;

    @FXML
    private TableColumn<Result, String> studentNameCol;


    public void resultFileWrite(Result result) {
        File file = new File("ResultsData.bin");
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;

        try {
            if (file.exists()) {
                fos = new FileOutputStream(file, true); // Append mode
                oos = new AppendableObjectOutputStream(fos);
            } else {
                fos = new FileOutputStream(file);
                oos = new ObjectOutputStream(fos);
            }
            oos.writeObject(result);
        } catch (IOException ex) {
            System.out.println("Error writing result: " + ex);
        } finally {
            try {
                if (oos != null) oos.close();
            } catch (IOException ex) {
                System.out.println("Error closing output stream: " + ex);
            }
        }
    }


    public ObservableList<Result> resultFileRead() {
        ObservableList<Result> results = FXCollections.observableArrayList();

        File file = new File("ResultsData.bin");
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        try {
            fis = new FileInputStream(file);
            ois = new ObjectInputStream(fis);

            Result result;
            try {
                while (true) {
                    result = (Result) ois.readObject();
                    results.add(result);
                }
            } catch (EOFException e) {

            }
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error reading results: " + ex);
        } finally {
            try {
                if (ois != null) ois.close();
            } catch (IOException ex) {
                System.out.println("Error closing input stream: " + ex);
            }
        }

        return results;
    }


    public void loadResultsToTable() {
        ObservableList<Result> results = resultFileRead();
        resultsTableView.setItems(results);
    }


    @FXML
    void compileResultsOnActionMouseclickButton(ActionEvent event) {

        statusLabel.setText("Results Compiled");
    }


    @FXML
    void publishResultsOnActionMouseclickButton(ActionEvent event) {

        statusLabel.setText("Results Published");
    }


    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {

        statusLabel.setText("Returning Home...");
    }
}
