package Mariyum;

import javafx.beans.property.*;

import java.io.Serializable;

public class Result implements Serializable {
    private StringProperty studentName;
    private StringProperty rollNumber;
    private DoubleProperty marks;
    private StringProperty grade;
    private StringProperty status;

    // Constructor with parameters for all fields
    public Result(String studentName, String rollNumber, double marks, String grade, String status) {
        this.studentName = new SimpleStringProperty(studentName);
        this.rollNumber = new SimpleStringProperty(rollNumber);
        this.marks = new SimpleDoubleProperty(marks);
        this.grade = new SimpleStringProperty(grade);
        this.status = new SimpleStringProperty(status);
    }

    // Getters and Setters for each field using properties
    public StringProperty studentNameProperty() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName.set(studentName);
    }

    public String getStudentName() {
        return studentName.get();
    }

    public StringProperty rollNumberProperty() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber.set(rollNumber);
    }

    public String getRollNumber() {
        return rollNumber.get();
    }

    public DoubleProperty marksProperty() {
        return marks;
    }

    public void setMarks(double marks) {
        this.marks.set(marks);
    }

    public double getMarks() {
        return marks.get();
    }

    public StringProperty gradeProperty() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade.set(grade);
    }

    public String getGrade() {
        return grade.get();
    }

    public StringProperty statusProperty() {
        return status;
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    public String getStatus() {
        return status.get();
    }

    // toString method for displaying object details
    @Override
    public String toString() {
        return "Result{" +
                "studentName='" + studentName.get() + '\'' +
                ", rollNumber='" + rollNumber.get() + '\'' +
                ", marks=" + marks.get() +
                ", grade='" + grade.get() + '\'' +
                ", status='" + status.get() + '\'' +
                '}';
    }

    // Method to calculate grade based on marks
    public void calculateGrade() {
        if (marks.get() >= 90) {
            grade.set("A+");
        } else if (marks.get() >= 80) {
            grade.set("A");
        } else if (marks.get() >= 70) {
            grade.set("B+");
        } else if (marks.get() >= 60) {
            grade.set("B");
        } else if (marks.get() >= 50) {
            grade.set("C");
        } else {
            grade.set("F");
        }
    }
}
