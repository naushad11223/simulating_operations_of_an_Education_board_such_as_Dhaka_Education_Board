package Mariyum;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.io.Serializable;

public class Attendance implements Serializable {
    private StringProperty studentName;
    private StringProperty rollNumber;
    private StringProperty examName;
    private StringProperty attendanceStatus;

    public Attendance(String studentName, String rollNumber, String examName, String attendanceStatus) {
        this.studentName = new SimpleStringProperty(studentName);
        this.rollNumber = new SimpleStringProperty(rollNumber);
        this.examName = new SimpleStringProperty(examName);
        this.attendanceStatus = new SimpleStringProperty(attendanceStatus);
    }


    public StringProperty studentNameProperty() {
        return studentName;
    }

    public String getStudentName() {
        return studentName.get();
    }

    public void setStudentName(String studentName) {
        this.studentName.set(studentName);
    }

    public StringProperty rollNumberProperty() {
        return rollNumber;
    }

    public String getRollNumber() {
        return rollNumber.get();
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber.set(rollNumber);
    }

    public StringProperty examNameProperty() {
        return examName;
    }

    public String getExamName() {
        return examName.get();
    }

    public void setExamName(String examName) {
        this.examName.set(examName);
    }

    public StringProperty attendanceStatusProperty() {
        return attendanceStatus;
    }

    public String getAttendanceStatus() {
        return attendanceStatus.get();
    }

    public void setAttendanceStatus(String attendanceStatus) {
        this.attendanceStatus.set(attendanceStatus);
    }

    @Override
    public String toString() {
        return "Attendance{" +
                "studentName='" + studentName.get() + '\'' +
                ", rollNumber='" + rollNumber.get() + '\'' +
                ", examName='" + examName.get() + '\'' +
                ", attendanceStatus='" + attendanceStatus.get() + '\'' +
                '}';
    }
}
