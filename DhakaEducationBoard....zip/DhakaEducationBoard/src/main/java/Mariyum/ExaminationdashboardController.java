package Mariyum;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ExaminationdashboardController {

    @FXML
    private Label dashboardLabel;


    private void loadScene(String fxmlFilePath, String sceneTitle, ActionEvent actionEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Mariyum/" + fxmlFilePath));
            Scene nextScene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setTitle(sceneTitle);
            stage.setScene(nextScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error loading FXML file: " + fxmlFilePath);
        }
    }

    @FXML
    void compileandpublishresultsOnActionMouseclickButton(ActionEvent event) {
        loadScene("ExaminationCompilesandpublishesresult.fxml", "Compile and Publish Results", event);
    }

    @FXML
    void issuecirtificateOnActionMouseclickButton(ActionEvent event) {
        loadScene("Examinationissuecertificate.fxml", "Issue Certificates", event);
    }

    @FXML
    void logOutOnActionMouseclickButton(ActionEvent event) {
        loadScene("Login.fxml", "Login", event); // Redirect to login page
    }

    @FXML
    void manageSchedulesOnActionMouseclickButton(ActionEvent event) {
        loadScene("Examinationmanageschedule.fxml", "Manage Schedules", event);
    }

    @FXML
    void notifychairmanOnActionMouseclickButton(ActionEvent event) {
        loadScene("Examinationnotifychairman.fxml", "Notify Chairman", event);
    }

    @FXML
    void registerstudentsOnActionMouseclickButton(ActionEvent event) {
        loadScene("Examinationregisterstudent.fxml", "Register Students", event);
    }

    @FXML
    void trackattendanceOnActionMouseclickButton(ActionEvent event) {
        loadScene("Examinationtrackattendance.fxml", "Track Attendance", event);
    }
}
