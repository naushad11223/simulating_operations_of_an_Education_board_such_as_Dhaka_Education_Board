package Mariyum;

import java.io.Serializable;

public class Message implements Serializable {

    private String messageContent;
    private String status;


    public Message(String messageContent, String status) {
        this.messageContent = messageContent;
        this.status = status;
    }


    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Message [messageContent=" + messageContent + ", status=" + status + "]";
    }
}
