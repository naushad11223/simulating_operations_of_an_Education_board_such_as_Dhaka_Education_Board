package Mariyum;

import java.io.Serializable;

public class Certificate implements Serializable {
    private String studentId;
    private String examId;
    private String status;

    public Certificate(String studentId, String examId, String status) {
        this.studentId = studentId;
        this.examId = examId;
        this.status = status;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getExamId() {
        return examId;
    }

    public void setExamId(String examId) {
        this.examId = examId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Certificate{" +
                "studentId='" + studentId + '\'' +
                ", examId='" + examId + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
