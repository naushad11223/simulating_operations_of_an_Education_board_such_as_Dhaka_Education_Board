package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.*;

public class ExaminationRegisterStudentController {

    @FXML
    private TableColumn<?, ?> SubjectCol;

    @FXML
    private TableColumn<?, ?> classCol;

    @FXML
    private TextField classTextfield;

    @FXML
    private ComboBox<String> examComboBox;

    @FXML
    private TableColumn<?, ?> examcol;

    @FXML
    private TableView<StudentRegistration> registeredStudentsTableView;

    @FXML
    private TableColumn<?, ?> rollNumberCol;

    @FXML
    private TextField rollNumberTextField;

    @FXML
    private Label searchStudentLabel;

    @FXML
    private TextField searchStudentTextField;

    @FXML
    private Label statusLabel;

    @FXML
    private TableColumn<?, ?> studentNameCol;

    @FXML
    private TextField studentNameTextField;

    @FXML
    private ComboBox<String> subjectComboBox;

    private ObservableList<StudentRegistration> studentList = FXCollections.observableArrayList();


    @FXML
    public void initialize() {

        ObservableList<String> exams = FXCollections.observableArrayList("Exam 1", "Exam 2", "Exam 3");
        examComboBox.setItems(exams);


        ObservableList<String> subjects = FXCollections.observableArrayList("Math", "English", "Science");
        subjectComboBox.setItems(subjects);
    }

    @FXML
    void clearOnActionMouseclickButton(ActionEvent event) {
        studentNameTextField.clear();
        rollNumberTextField.clear();
        classTextfield.clear();
        subjectComboBox.setValue(null);
        examComboBox.setValue(null);
    }

    @FXML
    void registerStudentOnActionMouseclickButton(ActionEvent event) {
        String studentName = studentNameTextField.getText();
        String rollNumber = rollNumberTextField.getText();
        String studentClass = classTextfield.getText();
        String exam = examComboBox.getValue();
        String subject = subjectComboBox.getValue();

        if (studentName.isEmpty() || rollNumber.isEmpty() || studentClass.isEmpty() || exam == null || subject == null) {
            statusLabel.setText("All fields are required!");
            return;
        }

        StudentRegistration student = new StudentRegistration(studentName, rollNumber, studentClass, exam, subject);
        studentList.add(student);
        registeredStudentsTableView.setItems(studentList);


        writeStudentToFile(student);

        statusLabel.setText("Student Registered Successfully!");
    }

    @FXML
    void returnHomeOnActionMouseclickButton(ActionEvent event) {

    }


    private void writeStudentToFile(StudentRegistration student) {
        File file = new File("StudentRegistrations.bin");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file, true))) {
            oos.writeObject(student);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public ObservableList<StudentRegistration> readStudentsFromFile() {
        ObservableList<StudentRegistration> students = FXCollections.observableArrayList();
        File file = new File("StudentRegistrations.bin");

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            while (true) {
                try {
                    StudentRegistration student = (StudentRegistration) ois.readObject();
                    students.add(student);
                } catch (EOFException e) {
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return students;
    }
}
