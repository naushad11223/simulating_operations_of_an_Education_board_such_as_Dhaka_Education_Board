package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ExaminationmanageschedulesController {

    @FXML
    private TableView<ExamSchedule> examsheduletableview;
    @FXML
    private TableView<Notification> notifactionTableView;
    @FXML
    private TableView<Invigilator> invigilatorsTableView;
    @FXML
    private TextArea statusupdatetextarea;

    private static final String SCHEDULE_FILE = "ExamScheduleData.bin";
    private static final String NOTIFICATION_FILE = "NotificationData.bin";
    private static final String INVIGILATOR_FILE = "InvigilatorData.bin";

    // Generic method to save a list to a file
    private <T> void saveToFile(List<T> list, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(list);
        } catch (IOException e) {
            e.printStackTrace();
            statusupdatetextarea.setText("Error saving data to file: " + filename);
        }
    }

    // Generic method to read a list from a file
    private <T> ObservableList<T> readFromFile(String filename) {
        ObservableList<T> list = FXCollections.observableArrayList();
        File file = new File(filename);

        if (!file.exists()) {
            System.out.println("File not found: " + filename + ". Initializing with an empty list.");
            return list; // Return empty list if file doesn't exist
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            list.addAll((List<T>) ois.readObject());
        } catch (EOFException e) {
            System.out.println("End of file reached for: " + filename);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            statusupdatetextarea.setText("Error reading data from file: " + filename);
        }
        return list;
    }

    @FXML
    void initialize() {
        // Load data from files and populate the TableViews
        try {
            examsheduletableview.setItems(readFromFile(SCHEDULE_FILE));
            notifactionTableView.setItems(readFromFile(NOTIFICATION_FILE));
            invigilatorsTableView.setItems(readFromFile(INVIGILATOR_FILE));
        } catch (Exception e) {
            e.printStackTrace();
            statusupdatetextarea.setText("Error initializing table views. Please check the data files.");
        }
    }

    @FXML
    void ExamVenueAssignedOnActionMouseClickButton(ActionEvent event) {
        // Example logic for assigning exam venues
        statusupdatetextarea.setText("Exam venues assigned successfully!");
        System.out.println("Exam venues assigned.");
    }

    @FXML
    void invigilatorAssignedOnActionButton(ActionEvent event) {
        // Example logic for assigning invigilators
        statusupdatetextarea.setText("Invigilators assigned successfully!");
        System.out.println("Invigilators assigned.");
    }

    @FXML
    void scheduleConflictResolvedOnActionButton(ActionEvent event) {
        // Example logic for resolving schedule conflicts
        statusupdatetextarea.setText("Schedule conflicts resolved!");
        System.out.println("Conflicts resolved.");
    }

    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {
        statusupdatetextarea.setText("Returning to dashboard...");
        System.out.println("Returning to dashboard.");
    }
}
