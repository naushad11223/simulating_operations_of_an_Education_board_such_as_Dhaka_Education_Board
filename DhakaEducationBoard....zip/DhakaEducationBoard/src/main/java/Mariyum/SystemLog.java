package Mariyum;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.io.Serializable;
import java.time.LocalDateTime;

public class SystemLog implements Serializable {

    private static final long serialVersionUID = 1L;

    private final StringProperty activityDescription;
    private final StringProperty status;
    private final StringProperty user;
    private final LocalDateTime timestamp;

    // Constructor
    public SystemLog(LocalDateTime timestamp, String activityDescription, String user, String status) {
        this.timestamp = timestamp;
        this.activityDescription = new SimpleStringProperty(activityDescription);
        this.status = new SimpleStringProperty(status);
        this.user = new SimpleStringProperty(user);
    }

    // Getters and setters
    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getActivityDescription() {
        return activityDescription.get();
    }

    public StringProperty activityDescriptionProperty() {
        return activityDescription;
    }

    public String getStatus() {
        return status.get();
    }

    public StringProperty statusProperty() {
        return status;
    }

    public String getUser() {
        return user.get();
    }

    public StringProperty userProperty() {
        return user;
    }
}
