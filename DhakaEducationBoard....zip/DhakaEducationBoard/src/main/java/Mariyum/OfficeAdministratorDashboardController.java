package Mariyum;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class OfficeAdministratorDashboardController {

    @FXML
    private Label dashboardLabel;

    private void loadScene(String fxmlFilePath, String sceneTitle, ActionEvent actionEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Mariyum/" + fxmlFilePath));
            Scene nextScene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setTitle(sceneTitle);
            stage.setScene(nextScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error loading FXML file: " + fxmlFilePath);
        }
    }

    @FXML
    void assignrolesOnActionMouseclickButton(ActionEvent event) {
        loadScene("Officeassignrole.fxml", "Assign Roles", event);
    }

    @FXML
    void generatereportsOnActionMouseclickButton(ActionEvent event) {
        loadScene("Officegeneratereport.fxml", "Generate Reports", event);
    }

    @FXML
    void logOutOnActionMouseclickButton(ActionEvent event) {
        loadScene("Login.fxml", "Login", event);
    }

    @FXML
    void managenotificationOnActionMouseclickButton(ActionEvent event) {
        loadScene("Officemanagenotification.fxml", "Manage Notifications", event);
    }

    @FXML
    void manageuseraccountsOnActionMouseclickButton(ActionEvent event) {
        loadScene("Officemanageuseraccount.fxml", "Manage User Accounts", event);
    }

    @FXML
    void monitorSystemActivityOnActionMouseclickButton(ActionEvent event) {
        loadScene("Officemonitorsystemactivity.fxml", "Monitor System Activity", event);
    }

    @FXML
    void notifychairmanOnActionMouseclickButton(ActionEvent event) {
        loadScene("Officenotifychairman.fxml", "Notify Chairman", event);
    }

    @FXML
    void tracefeePaymentOnActionMouseclickButton(ActionEvent event) {
        loadScene("Officetrackfeepayment.fxml", "Trace Fee Payment", event);
    }

    @FXML
    void viewexamschedulesOnActionMouseclickButton(ActionEvent event) {
        loadScene("Officeviewexamschedule.fxml", "View Exam Schedules", event);
    }
}
