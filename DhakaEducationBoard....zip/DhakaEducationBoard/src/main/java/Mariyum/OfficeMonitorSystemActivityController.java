package Mariyum;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class OfficeMonitorSystemActivityController {

    @FXML
    private TableColumn<SystemLog, String> activityDescriptionCol;

    @FXML
    private Label feedbackLabel;

    @FXML
    private ComboBox<String> filterComboBox;

    @FXML
    private TableColumn<SystemLog, String> statusCol;

    @FXML
    private TableView<SystemLog> systemLogsTableview;

    @FXML
    private TableColumn<SystemLog, String> timestampCol;

    @FXML
    private TableColumn<SystemLog, String> userCol;

    private static final String FILE_NAME = "SystemLogsData.bin";

    // Method to write a system log to the file
    public void systemLogFileWrite(SystemLog log) {
        File file = new File(FILE_NAME);
        try (FileOutputStream fos = new FileOutputStream(file, true);
             ObjectOutputStream oos = file.exists() ? new AppendableObjectOutputStream(fos) : new ObjectOutputStream(fos)) {
            oos.writeObject(log);
            feedbackLabel.setText("Log saved successfully!");
        } catch (IOException ex) {
            feedbackLabel.setText("Error saving log: " + ex.getMessage());
        }
    }


    public ObservableList<SystemLog> systemLogFileRead() {
        ObservableList<SystemLog> logs = FXCollections.observableArrayList();
        File file = new File(FILE_NAME);

        if (!file.exists()) return logs;

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            while (true) {
                SystemLog log = (SystemLog) ois.readObject();
                logs.add(log);
            }
        } catch (EOFException eof) {
            // End of file reached, normal termination
        } catch (IOException | ClassNotFoundException ex) {
            feedbackLabel.setText("Error reading logs: " + ex.getMessage());
        }

        return logs;
    }

    // Action handler for the "Filter Logs" button
    @FXML
    void filterlogsOnActionMouseclickButton(ActionEvent event) {
        // Implement filtering logic here
        feedbackLabel.setText("Filtering logs...");
    }

    // Action handler for the "Refresh Logs" button
    @FXML
    void refreshLOGSOnActionMouseclickButton(ActionEvent event) {
        systemLogsTableview.setItems(systemLogFileRead());
        feedbackLabel.setText("Logs refreshed!");
    }

    // Action handler for the "Return Home" button
    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {
        feedbackLabel.setText("Returning to home...");
        // Implement navigation logic if needed
    }

    // Initialize method to set up the TableView and ComboBox
    @FXML
    public void initialize() {
        filterComboBox.setItems(FXCollections.observableArrayList("All", "Active", "Inactive"));

        // Set up the TableColumn bindings
        activityDescriptionCol.setCellValueFactory(cellData -> cellData.getValue().activityDescriptionProperty());
        statusCol.setCellValueFactory(cellData -> cellData.getValue().statusProperty());

        // Format LocalDateTime into String for display
        timestampCol.setCellValueFactory(cellData -> {
            LocalDateTime timestamp = cellData.getValue().getTimestamp();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            return new SimpleStringProperty(timestamp.format(formatter));  // Convert LocalDateTime to String
        });

        userCol.setCellValueFactory(cellData -> cellData.getValue().userProperty());

        // Load system logs into the TableView
        systemLogsTableview.setItems(systemLogFileRead());
    }

    // Custom ObjectOutputStream to handle appending objects
    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {
            reset(); // Prevent overwriting the file
        }
    }
}
