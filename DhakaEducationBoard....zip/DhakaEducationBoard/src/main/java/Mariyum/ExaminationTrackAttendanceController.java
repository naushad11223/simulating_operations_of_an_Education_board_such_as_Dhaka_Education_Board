package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;
import java.util.ArrayList;

public class ExaminationTrackAttendanceController {

    @FXML
    private TableColumn<Attendance, String> attendanceStatusCol;

    @FXML
    private TableView<Attendance> attendanceTableView;

    @FXML
    private DatePicker datePicker;

    @FXML
    private ComboBox<String> examComboBox;

    @FXML
    private TableColumn<Attendance, String> examNameCol;

    @FXML
    private TableColumn<Attendance, String> rollNumberCol;

    @FXML
    private Label statusLabel;

    @FXML
    private TableColumn<Attendance, String> studentNameCol;


    @FXML
    void markAttendanceOnActionMouseclickButton(ActionEvent event) {

        String studentName = "John Doe"; // Example student
        String rollNumber = "12345"; // Example roll number
        String examName = examComboBox.getValue();
        String attendanceStatus = "Present"; // This could be dynamic

        Attendance attendance = new Attendance(studentName, rollNumber, examName, attendanceStatus);


        writeAttendanceToFile(attendance);


        attendanceTableView.getItems().add(attendance);
        statusLabel.setText("Attendance marked successfully!");
    }

    @FXML
    void returnHomeOnActionMouseclickButton(ActionEvent event) {
        examComboBox.getSelectionModel().clearSelection();
        datePicker.setValue(null);
        attendanceTableView.getItems().clear();
        statusLabel.setText("Return to home page.");
    }


    @FXML
    void uploadFileOnActionMouseclickButton(ActionEvent event) {

    }

    @FXML
    void viewReportOnActionMouseclickButton(ActionEvent event) {

    }

    public void writeAttendanceToFile(Attendance attendance) {
        File file = new File("AttendanceData.bin");
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;

        try {
            if (file.exists()) {
                fos = new FileOutputStream(file, true); // Append mode
                oos = new AppendableObjectOutputStream(fos);
            } else {
                fos = new FileOutputStream(file);
                oos = new ObjectOutputStream(fos);
            }
            oos.writeObject(attendance);

        } catch (IOException ex) {
            System.out.println(ex);
        } finally {
            try {
                if (oos != null) oos.close();
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }
    }

    public ObservableList<Attendance> readAttendanceFromFile() {
        ObservableList<Attendance> attendanceList = FXCollections.observableArrayList();

        File file = new File("AttendanceData.bin");
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        try {
            fis = new FileInputStream(file);
            ois = new ObjectInputStream(fis);

            Attendance attendance;
            while (true) {
                try {
                    attendance = (Attendance) ois.readObject();
                    attendanceList.add(attendance);
                } catch (EOFException e) {
                    break;
                }
            }

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex);
        } finally {
            try {
                if (ois != null) ois.close();
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }

        return attendanceList;
    }

    public void initialize() {

        ObservableList<Attendance> attendanceList = readAttendanceFromFile();
        attendanceTableView.setItems(attendanceList);

        studentNameCol.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        rollNumberCol.setCellValueFactory(new PropertyValueFactory<>("rollNumber"));
        examNameCol.setCellValueFactory(new PropertyValueFactory<>("examName"));
        attendanceStatusCol.setCellValueFactory(new PropertyValueFactory<>("attendanceStatus"));
        examComboBox.setItems(FXCollections.observableArrayList("Exam 1", "Exam 2", "Exam 3"));
    }

    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {

        }
    }
}
