package Mariyum;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ExaminationcontrollerLoginController {

    @FXML
    private Label dhakaeducationboardLabel;

    @FXML
    private Label loginsuccessfulLabel;

    @FXML
    private TextField passwordtf;

    @FXML
    private TextField useridtf;

    @FXML
    void forgotPasswordonActionMouseClickButton(ActionEvent event) {

    }

    @FXML
    void loginonActionMouseClickButton(ActionEvent event) {

    }

}
