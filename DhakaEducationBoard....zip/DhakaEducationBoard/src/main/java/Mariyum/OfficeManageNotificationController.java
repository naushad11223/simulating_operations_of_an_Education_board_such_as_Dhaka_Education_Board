package Mariyum;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.*;
import java.util.List;

public class OfficeManageNotificationController {

    @FXML
    private Label feedbackLabel;

    @FXML
    private TextField messageContentField;

    @FXML
    private TableColumn<Notification, Integer> notificationIdCol;

    @FXML
    private TableView<Notification> notificationsTableView;

    @FXML
    private TableColumn<Notification, String> recipientCol;

    @FXML
    private TextField recipientField;

    @FXML
    private TableColumn<Notification, String> rollNumberContentCol;

    @FXML
    private ChoiceBox<String> statusChoiceBox;

    @FXML
    private TableColumn<Notification, String> statusCol;


    private void writeNotificationToFile(Notification notification) {
        File file = new File("NotificationData.bin");
        try (FileOutputStream fos = new FileOutputStream(file, true);
             ObjectOutputStream oos = (file.length() == 0) ? new ObjectOutputStream(fos) : new AppendableObjectOutputStream(fos)) {

            oos.writeObject(notification);

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }


    private ObservableList<Notification> readNotificationsFromFile() {
        ObservableList<Notification> notifications = FXCollections.observableArrayList();
        File file = new File("NotificationData.bin");

        if (!file.exists()) {
            return notifications; // Return empty list if the file doesn't exist
        }

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {

            while (true) {
                try {
                    Notification notification = (Notification) ois.readObject();
                    notifications.add(notification);
                } catch (EOFException e) {
                    break; // End of file reached
                }
            }

        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }

        return notifications;
    }


    @FXML
    private void sendNotificationOnActionMouseclickButton(ActionEvent event) {
        String messageContent = messageContentField.getText();
        String recipient = recipientField.getText();
        String status = statusChoiceBox.getValue();

        if (messageContent.isEmpty() || recipient.isEmpty() || status == null) {
            feedbackLabel.setText("Please fill in all fields.");
            return;
        }

        Notification newNotification = new Notification(
                notificationsTableView.getItems().size() + 1, // Simple ID based on current size
                messageContent, recipient, status
        );

        writeNotificationToFile(newNotification);
        feedbackLabel.setText("Notification Sent!");

        // Update TableView
        notificationsTableView.getItems().add(newNotification);
        clearInputFields();
    }

    /**
     * Updates the selected notification.
     */
    @FXML
    private void updateNotificationOnActionMouseclickButton(ActionEvent event) {
        Notification selectedNotification = notificationsTableView.getSelectionModel().getSelectedItem();

        if (selectedNotification != null) {
            selectedNotification.setMessageContent(messageContentField.getText());
            selectedNotification.setRecipient(recipientField.getText());
            selectedNotification.setStatus(statusChoiceBox.getValue());

            // Update file
            updateNotificationsInFile();
            feedbackLabel.setText("Notification Updated!");

            // Refresh TableView
            notificationsTableView.refresh();
            clearInputFields();
        } else {
            feedbackLabel.setText("Please select a notification to update.");
        }
    }

    /**
     * Deletes the selected notification.
     */
    @FXML
    private void deleteNotificationOnActionMouseclickButton(ActionEvent event) {
        Notification selectedNotification = notificationsTableView.getSelectionModel().getSelectedItem();

        if (selectedNotification != null) {
            notificationsTableView.getItems().remove(selectedNotification);

            // Update file
            updateNotificationsInFile();
            feedbackLabel.setText("Notification Deleted!");
        } else {
            feedbackLabel.setText("Please select a notification to delete.");
        }
    }

    /**
     * Updates the notification file after modifications.
     */
    private void updateNotificationsInFile() {
        List<Notification> notifications = notificationsTableView.getItems();

        try (FileOutputStream fos = new FileOutputStream("NotificationData.bin");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {

            for (Notification notification : notifications) {
                oos.writeObject(notification);
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Clears the input fields.
     */
    private void clearInputFields() {
        messageContentField.clear();
        recipientField.clear();
        statusChoiceBox.setValue(null);
    }

    /**
     * Initializes the controller and loads notifications from the file.
     */
    public void initialize() {
        ObservableList<Notification> notifications = readNotificationsFromFile();
        notificationsTableView.setItems(notifications);

        // Configure ChoiceBox options
        statusChoiceBox.setItems(FXCollections.observableArrayList("Pending", "Sent", "Failed"));
    }
}
