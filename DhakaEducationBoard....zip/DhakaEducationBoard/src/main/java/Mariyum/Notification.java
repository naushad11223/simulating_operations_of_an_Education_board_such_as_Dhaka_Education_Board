package Mariyum;

import java.io.Serializable;

public class Notification implements Serializable {
    private static final long serialVersionUID = 1L;

    // Fields
    private int notificationId;
    private String messageContent;
    private String recipient;
    private String status;

    // Constructor
    public Notification(int notificationId, String messageContent, String recipient, String status) {
        this.notificationId = notificationId;
        this.messageContent = messageContent;
        this.recipient = recipient;
        this.status = status;
    }

    // Getters
    public int getNotificationId() {
        return notificationId;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getStatus() {
        return status;
    }

    // Setters
    public void setNotificationId(int notificationId) {
        this.notificationId = notificationId;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Overridden toString method
    @Override
    public String toString() {
        return "Notification [ID: " + notificationId +
                ", Message: " + messageContent +
                ", Recipient: " + recipient +
                ", Status: " + status + "]";
    }

    // Additional utility methods (Optional)
    public boolean isUnread() {
        return "Unread".equalsIgnoreCase(status);
    }

    public void markAsRead() {
        this.status = "Read";
    }
}
