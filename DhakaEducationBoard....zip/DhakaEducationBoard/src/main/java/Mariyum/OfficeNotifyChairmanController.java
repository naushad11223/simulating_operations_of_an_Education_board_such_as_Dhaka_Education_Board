package Mariyum;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import java.io.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class OfficeNotifyChairmanController {

    @FXML
    private TextArea messageInputTextArea;

    @FXML
    private Label statusLabel;

    private static final String FILE_NAME = "MessagesData.bin";

    // Method to write a message to the file
    public void messageFileWrite(Message message) {
        File file = new File(FILE_NAME);
        try (FileOutputStream fos = new FileOutputStream(file, true);
             ObjectOutputStream oos = file.exists() ? new AppendableObjectOutputStream(fos) : new ObjectOutputStream(fos)) {
            oos.writeObject(message);
            statusLabel.setText("Message sent successfully!");
        } catch (IOException ex) {
            statusLabel.setText("Error sending message: " + ex.getMessage());
        }
    }

    // Method to read all messages from the file
    public ObservableList<Message> messageFileRead() {
        ObservableList<Message> messages = FXCollections.observableArrayList();
        File file = new File(FILE_NAME);

        if (!file.exists()) return messages;

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            while (true) {
                Message message = (Message) ois.readObject();
                messages.add(message);
            }
        } catch (EOFException eof) {
            // End of file reached, normal termination
        } catch (IOException | ClassNotFoundException ex) {
            statusLabel.setText("Error reading messages: " + ex.getMessage());
        }

        return messages;
    }

    // Action handler for the "Notify Chairman" button
    @FXML
    void notifyChairmanOnActionMouseclickButton(ActionEvent event) {
        String messageContent = messageInputTextArea.getText();
        if (messageContent.isEmpty()) {
            statusLabel.setText("Please enter a message.");
            return;
        }

        // Create the message object
        Message message = new Message(messageContent, "Sent");

        // Call the messageFileWrite method to save the message
        messageFileWrite(message);

        // Clear the text area after sending
        messageInputTextArea.clear();
    }

    // Action handler for the "Return Home" button
    @FXML
    void returnhomeOnActionMouseclickButton(ActionEvent event) {
        statusLabel.setText("Returning to home...");
        // Implement navigation logic if needed
    }

    // Custom ObjectOutputStream to handle appending objects
    private static class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {
            reset(); // Prevent overwriting the file
        }
    }
}
